import Veiculos.Veiculo;

import java.util.ArrayList;

public class Cliente extends Usuario {
    public Cliente(String nome, String nomeUsuario, String senha) {
        super(nome, nomeUsuario, senha);
    }
}
