public class Vendedor extends Funcionario {

    public Vendedor(String nome, String nomeUsuario, String senha, int cadastro, double salario, int vendas) {
        super(nome, nomeUsuario, senha, cadastro, salario, vendas);
    }

}
