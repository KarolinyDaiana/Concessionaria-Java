public class Venda {
}
